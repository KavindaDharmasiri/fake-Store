import React, { Component } from 'react';

class Item extends Component {
    render() { 
        return (
            <h1>Item Screen</h1>
        );
    }
}
 
export default Item;
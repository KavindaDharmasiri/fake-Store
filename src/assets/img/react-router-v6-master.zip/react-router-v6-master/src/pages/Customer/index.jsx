import React, { Component } from 'react';

class Customer extends Component {
    render() { 
        return (
            <h1>Customer Screen</h1>
        );
    }
}
 
export default Customer;
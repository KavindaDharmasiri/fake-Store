import React, { Component } from 'react';

class Setting extends Component {
    render() { 
        return (
            <h1>Setting Screen</h1>
        );
    }
}
 
export default Setting;